package com.azdrive.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.TextView;

import org.json.JSONObject;

/** Opens with the requested launch bounds and records the window size the firmware actually granted. */
public class ProbeActivity extends Activity {
    private boolean done = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("AZ Drive window probe");
        t.setTextColor(Color.WHITE);
        t.setBackgroundColor(0xFF0B1D44);
        t.setGravity(Gravity.CENTER);
        setContentView(t);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (!f || done) return;
        done = true;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                String old = getSharedPreferences("az", MODE_PRIVATE).getString("probe", "{}");
                JSONObject o = new JSONObject(old);
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                o.put("pending", false).put("gw", getWindow().getDecorView().getWidth()).put("gh", getWindow().getDecorView().getHeight())
                    .put("sw", dm.widthPixels).put("sh", dm.heightPixels).put("multiWindow", isInMultiWindowMode());
                getSharedPreferences("az", MODE_PRIVATE).edit().putString("probe", o.toString()).apply();
            } catch (Exception ignored) { }
            finish();
        }, 900);
    }
}
