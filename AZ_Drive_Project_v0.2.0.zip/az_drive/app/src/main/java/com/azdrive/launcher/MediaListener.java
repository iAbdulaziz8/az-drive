package com.azdrive.launcher;

import android.service.notification.NotificationListenerService;

/**
 * Empty on purpose: enabling this listener in Android's "Notification access" settings is what
 * authorizes MediaSessionManager.getActiveSessions(ComponentName) for the launcher.
 * No notification content is read or stored.
 */
public class MediaListener extends NotificationListenerService {
}
