package com.azdrive.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.Manifest;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.location.Location;
import android.location.LocationManager;
import android.location.Criteria;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.layers.CircleLayer;
import org.maplibre.android.style.layers.Property;
import org.maplibre.android.style.layers.PropertyFactory;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.FeatureCollection;
import org.maplibre.geojson.LineString;
import org.maplibre.geojson.Point;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout root;
    private MapView mapView;
    private MapLibreMap nativeMap;
    private GeoJsonSource routeSource, destinationSource, userSource;
    private Location lastLocation;
    private Double destinationLat = null, destinationLon = null;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String MAP_STYLE = "https://tiles.openfreemap.org/styles/liberty";
    // Public community endpoint for development; production deployment should use a managed/self-hosted Valhalla service.
    private static final String VALHALLA_ROUTE = "https://valhalla1.openstreetmap.de/route";
    private static final String GEOCODER = "https://nominatim.openstreetmap.org/search";
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER_REQUEST = 7001;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setGeolocationEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "AZ");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                if (granted) callback.invoke(origin, true, false);
                else { callback.invoke(origin, false, false); runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 7101);
                }); }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        web.setBackgroundColor(0xFF050B1F);
        root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        MapLibre.getInstance(this);
        mapView = new MapView(this);
        mapView.setVisibility(View.GONE);
        root.addView(mapView, new FrameLayout.LayoutParams(1, 1));
        setContentView(root);
        mapView.onCreate(state);
        mapView.getMapAsync(map -> {
            nativeMap = map;
            map.setStyle(new Style.Builder().fromUri(MAP_STYLE), style -> {
                installMapLayers(style);
                map.setCameraPosition(new CameraPosition.Builder().target(new LatLng(24.7136, 46.6753)).zoom(11.5).build());
                map.addOnMapClickListener(point -> { selectDestination(point.getLatitude(), point.getLongitude()); return true; });
                mapView.setVisibility(View.VISIBLE);
                syncMapOverlay();
            });
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) { super.onPageFinished(view, url); syncMapOverlay(); }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override public void onWindowFocusChanged(boolean focus) { super.onWindowFocusChanged(focus); if (focus) applyImmersive(); }
    @Override protected void onStart() { super.onStart(); if (mapView != null) mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); if (mapView != null) mapView.onResume(); applyImmersive(); handler.postDelayed(this::syncMapOverlay, 250); }
    @Override protected void onPause() { if (web != null) web.onPause(); if (mapView != null) mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { if (mapView != null) mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); if (mapView != null) mapView.onLowMemory(); }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (mapView != null) mapView.onSaveInstanceState(out); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 7101) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) handler.postDelayed(this::locateUser, 350);
            else notifyMap("إذن الموقع مرفوض؛ فعّله من إعدادات التطبيق لاستخدام الملاحة.");
            if (web != null) web.post(() -> web.evaluateJavascript("if(window.refreshPermissions)refreshPermissions()", null));
        }
    }

    @Override public void onBackPressed() { /* Keep the launcher on its dashboard. */ }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (mapView != null) { mapView.onDestroy(); mapView = null; }
        if (web != null) { web.removeJavascriptInterface("AZ"); web.destroy(); web = null; }
        super.onDestroy();
    }

    private void syncMapOverlay() {
        if (web == null || mapView == null || root == null) return;
        web.evaluateJavascript("(function(){var e=document.getElementById('azmap');if(!e)return null;var r=e.getBoundingClientRect();return JSON.stringify({x:r.left,y:r.top,w:r.width,h:r.height,visible:r.width>0&&r.height>0});})()", value -> {
            try {
                if (value == null || "null".equals(value)) { mapView.setVisibility(View.GONE); return; }
                String json = value;
                if (json.startsWith("\"") && json.endsWith("\"")) json = json.substring(1, json.length()-1).replace("\\\"", "\"").replace("\\\\", "\\");
                JSONObject r = new JSONObject(json);
                if (!r.optBoolean("visible", false)) { mapView.setVisibility(View.GONE); return; }
                float d = getResources().getDisplayMetrics().density;
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(1, Math.round((float)r.getDouble("w")*d)), Math.max(1, Math.round((float)r.getDouble("h")*d)));
                lp.leftMargin = Math.round((float)r.getDouble("x")*d);
                lp.topMargin = Math.round((float)r.getDouble("y")*d);
                mapView.setLayoutParams(lp);
                mapView.setVisibility(View.VISIBLE);
                mapView.bringToFront();
                mapView.requestLayout();
            } catch (Exception e) { Log.w("AZDriveMap", "Map overlay layout sync failed", e); }
        });
    }

    private void installMapLayers(Style style) {
        try {
            routeSource = new GeoJsonSource("az-route-source", FeatureCollection.fromFeatures(new Feature[0]));
            destinationSource = new GeoJsonSource("az-destination-source", FeatureCollection.fromFeatures(new Feature[0]));
            userSource = new GeoJsonSource("az-user-source", FeatureCollection.fromFeatures(new Feature[0]));
            style.addSource(routeSource); style.addSource(destinationSource); style.addSource(userSource);
            style.addLayer(new LineLayer("az-route-line", "az-route-source").withProperties(
                PropertyFactory.lineColor("#159ee8"), PropertyFactory.lineWidth(5f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)));
            style.addLayer(new CircleLayer("az-destination-dot", "az-destination-source").withProperties(
                PropertyFactory.circleRadius(8f), PropertyFactory.circleColor("#ef4444"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(2f)));
            style.addLayer(new CircleLayer("az-user-dot", "az-user-source").withProperties(
                PropertyFactory.circleRadius(7f), PropertyFactory.circleColor("#168fe5"),
                PropertyFactory.circleStrokeColor("#ffffff"), PropertyFactory.circleStrokeWidth(3f)));
        } catch (Exception e) { Log.e("AZDriveMap", "Unable to initialize map layers", e); }
    }

    private void setPointSource(GeoJsonSource source, double lat, double lon) {
        if (source != null) source.setGeoJson(Feature.fromGeometry(Point.fromLngLat(lon, lat)));
    }

    private void selectDestination(double lat, double lon) {
        setPointSource(destinationSource, lat, lon);
        if (lastLocation != null) requestValhallaRoute(lastLocation.getLatitude(), lastLocation.getLongitude(), lat, lon);
        else notifyMap("تم تحديد الوجهة. اضغط زر موقعي لبدء حساب المسار.");
    }

    private void notifyMap(String message) {
        if (web != null) web.post(() -> web.evaluateJavascript("(function(){var e=document.getElementById('mapstatus');if(e)e.textContent=" + JSONObject.quote(message) + ";})()", null));
    }

    private void geocode(String query) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                String u = GEOCODER + "?format=jsonv2&limit=1&q=" + URLEncoder.encode(query, "UTF-8");
                c = (HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(9000); c.setReadTimeout(9000);
                c.setRequestProperty("User-Agent", "AZDrive/0.3 (Android launcher personal use)");
                JSONArray a = new JSONArray(readAll(c.getInputStream()));
                if (a.length() == 0) throw new Exception("لم يتم العثور على الوجهة");
                JSONObject hit = a.getJSONObject(0); double lat = hit.getDouble("lat"), lon = hit.getDouble("lon");
                destinationLat = lat; destinationLon = lon;
                handler.post(() -> {
                    if (nativeMap != null) nativeMap.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15));
                    setPointSource(destinationSource, lat, lon);
                    notifyMap(hit.optString("display_name", "تم العثور على الوجهة"));
                    if (lastLocation != null) requestValhallaRoute(lastLocation.getLatitude(), lastLocation.getLongitude(), lat, lon);
                    else { notifyMap("تم العثور على الوجهة؛ جارٍ تحديد موقعك لحساب المسار…"); locateUser(); }
                });
            } catch (Exception e) { notifyMap("تعذر البحث: " + e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }, "AZ-Map-Geocode").start();
    }

    private void locateUser() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 7101);
            notifyMap("يرجى السماح بالوصول إلى الموقع ثم الضغط مرة أخرى."); return;
        }
        try {
            LocationManager lm = (LocationManager)getSystemService(LOCATION_SERVICE);
            Location best = null;
            for (String provider : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(provider);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best == null) { notifyMap("جارٍ انتظار تحديد موقع GPS…");
                String provider = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
                lm.requestSingleUpdate(provider, l -> showUserLocation(l), null); return; }
            showUserLocation(best);
        } catch (SecurityException e) { notifyMap("إذن الموقع غير متاح."); }
        catch (Exception e) { notifyMap("تعذر تحديد الموقع."); }
    }

    private void showUserLocation(Location location) {
        if (location == null) return; lastLocation = location;
        if (destinationLat != null && destinationLon != null) requestValhallaRoute(location.getLatitude(), location.getLongitude(), destinationLat, destinationLon);
        double lat = location.getLatitude(), lon = location.getLongitude();
        handler.post(() -> { setPointSource(userSource, lat, lon);
            if (nativeMap != null) nativeMap.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15));
            notifyMap("موقعك الحالي · " + String.format(java.util.Locale.US, "%.5f, %.5f", lat, lon)); });
    }

    private void requestValhallaRoute(double fromLat, double fromLon, double toLat, double toLon) {
        notifyMap("جارٍ حساب المسار…");
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                JSONObject req = new JSONObject(); JSONArray locations = new JSONArray();
                locations.put(new JSONObject().put("lat", fromLat).put("lon", fromLon));
                locations.put(new JSONObject().put("lat", toLat).put("lon", toLon));
                req.put("locations", locations).put("costing", "auto").put("units", "kilometers").put("language", "ar-SA");
                req.put("directions_options", new JSONObject().put("units", "kilometers"));
                c = (HttpURLConnection)new URL(VALHALLA_ROUTE).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
                c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream os = c.getOutputStream()) { os.write(req.toString().getBytes("UTF-8")); }
                String body = readAll(c.getInputStream()); JSONObject response = new JSONObject(body);
                JSONObject trip = response.getJSONObject("trip"); JSONArray legs = trip.getJSONArray("legs");
                String shape = legs.getJSONObject(0).getString("shape"); List<Point> points = decodePolyline6(shape);
                if (points.size() < 2) throw new Exception("المسار غير مكتمل");
                JSONObject summary = trip.getJSONObject("summary"); double km = summary.optDouble("length", 0); int mins = (int)Math.round(summary.optDouble("time", 0)/60.0);
                JSONArray maneuvers = legs.getJSONObject(0).optJSONArray("maneuvers");
                LineString line = LineString.fromLngLats(points);
                handler.post(() -> {
                    if (routeSource != null) routeSource.setGeoJson(Feature.fromGeometry(line));
                    if (nativeMap != null) nativeMap.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngBounds(
                        new org.maplibre.android.geometry.LatLngBounds.Builder().include(new LatLng(fromLat,fromLon)).include(new LatLng(toLat,toLon)).build(), 60));
                    notifyMap(String.format(java.util.Locale.US, "المسار جاهز · %.1f كم · %d دقيقة تقريبًا", km, mins));
                    publishManeuvers(maneuvers);
                });
            } catch (Exception e) { Log.w("AZDriveMap", "Valhalla route request failed", e); notifyMap("تعذر حساب المسار حاليًا: " + e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }, "AZ-Valhalla-Route").start();
    }

    private void publishManeuvers(JSONArray maneuvers) {
        if (maneuvers == null || web == null) return;
        try { JSONArray compact = new JSONArray(); for (int i=0;i<Math.min(4,maneuvers.length());i++) {
            JSONObject m=maneuvers.getJSONObject(i); compact.put(new JSONObject().put("instruction",m.optString("instruction")).put("length",m.optDouble("length",0)));
        } web.post(() -> web.evaluateJavascript("window.dispatchEvent(new CustomEvent(\'az-maneuvers\',{detail:" + compact.toString() + "}));", null)); } catch (Exception ignored) {}
    }

    private List<Point> decodePolyline6(String encoded) {
        List<Point> points = new ArrayList<>(); int index=0, lat=0, lon=0;
        while (index < encoded.length()) {
            int[] a=decodeValue(encoded,index); lat += a[0]; index=a[1];
            int[] b=decodeValue(encoded,index); lon += b[0]; index=b[1];
            points.add(Point.fromLngLat(lon/1e6, lat/1e6));
        } return points;
    }
    private int[] decodeValue(String s,int index) { int result=0,shift=0,b; do { b=s.charAt(index++)-63; result|=(b&0x1f)<<shift; shift+=5; } while(b>=0x20); int value=(result&1)!=0?~(result>>1):(result>>1); return new int[]{value,index}; }
    private String readAll(InputStream in) throws Exception { StringBuilder b=new StringBuilder(); try(BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){String line;while((line=r.readLine())!=null)b.append(line);} return b.toString(); }

    private class Bridge {
        @JavascriptInterface public void launch(String packageName) {
            if (packageName == null || packageName.trim().isEmpty()) return;
            runOnUiThread(() -> {
                try { Intent i = getPackageManager().getLaunchIntentForPackage(packageName); if (i != null) startActivity(i); }
                catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void put(String key, String value) {
            if (key != null && key.startsWith("az.") && value != null && value.length() < 4_000_000)
                getSharedPreferences("az", MODE_PRIVATE).edit().putString(key, value).apply();
        }
        @JavascriptInterface public String get(String key) {
            return key != null && key.startsWith("az.") ? getSharedPreferences("az", MODE_PRIVATE).getString(key, null) : null;
        }
        @JavascriptInterface public void settings() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public boolean locationGranted() {
            if (Build.VERSION.SDK_INT < 23) return true;
            return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23 && !locationGranted()) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 7101);
                    } else {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 7101);
                    }
                }
            });
        }
        @JavascriptInterface public boolean notificationAccess() {
            String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            return enabled != null && enabled.contains(getPackageName() + "/" + AZNotificationListener.class.getName());
        }
        @JavascriptInterface public void openNotificationSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
            });
        }
        @JavascriptInterface public String mediaState() { return AZNotificationListener.stateJson(); }
        @JavascriptInterface public void mediaControl(String action) { AZNotificationListener.control(action); }
        @JavascriptInterface public void mediaSeek(long positionMs) { AZNotificationListener.seekTo(positionMs); }
        @JavascriptInterface public void openAppDetails() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {} });
        }
        @JavascriptInterface public void mapRelayout() { runOnUiThread(() -> syncMapOverlay()); }
        @JavascriptInterface public void mapSearch(String query) { if (query != null && !query.trim().isEmpty()) geocode(query.trim()); }
        @JavascriptInterface public void mapLocate() { runOnUiThread(() -> locateUser()); }
        @JavascriptInterface public boolean mapsInstalled() {
            try { getPackageManager().getPackageInfo("com.google.android.apps.maps", 0); return true; }
            catch (Exception e) { return false; }
        }
        @JavascriptInterface public String mapsEmbeddingStatus() {
            // Android cross-app embedding requires the target app to opt in; package presence alone is insufficient.
            return mapsInstalled() ? "installed_embedding_not_confirmed" : "not_installed";
        }
        @JavascriptInterface public String list() {
            try {
                Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                JSONArray apps = new JSONArray();
                for (ResolveInfo r : getPackageManager().queryIntentActivities(query, 0)) {
                    if (r.activityInfo == null) continue;
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    Drawable icon = r.loadIcon(getPackageManager());
                    Bitmap bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    icon.setBounds(0, 0, 96, 96);
                    icon.draw(canvas);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    apps.put(new JSONObject().put("p", pkg)
                        .put("n", r.loadLabel(getPackageManager()).toString())
                        .put("i", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)));
                    bitmap.recycle();
                }
                return apps.toString();
            } catch (Exception e) { return "[]"; }
        }
    }
}
