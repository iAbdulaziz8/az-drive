package com.azdrive.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.role.RoleManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import android.graphics.Rect;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fcb;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ---- media
    private MediaSessionManager msm;
    private final List<MediaController> ctrls = new ArrayList<>();
    private String pref = "";
    private String lastArtKey = "";
    private String lastArt = null;
    private final MediaSessionManager.OnActiveSessionsChangedListener sessListener = list -> setControllers(list);
    private final MediaController.Callback ccb = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState s) { pushMedia(); }
        @Override public void onMetadataChanged(MediaMetadata m) { pushMedia(); }
        @Override public void onSessionDestroyed() { ui.post(MainActivity.this::startMedia); }
    };

    // ---- location
    private LocationManager lm;
    private boolean locWanted = false;
    private final LocationListener locListener = new LocationListener() {
        @Override public void onLocationChanged(Location l) { pushLoc(l); }
        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { }
        @Override public void onStatusChanged(String p, int s, Bundle b) { }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
        });
        web.addJavascriptInterface(new Bridge(), "AZ");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fcb != null) fcb.onReceiveValue(null);
                fcb = cb;
                try { startActivityForResult(p.createIntent(), 7); } catch (Exception e) { fcb = null; return false; }
                return true;
            }
        });
        web.setBackgroundColor(0xFF050B1F);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        immersive();
        pushPerm();
        pushProbe();
        startMedia();
        if (locWanted) startLoc();
    }
    @Override protected void onPause() {
        stopLoc();
        web.onPause();
        super.onPause();
    }
    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == 8) { jsJson("azPerm", permJson()); }
        if (rq == 7 && fcb != null) { fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null; }
    }
    @Override public void onRequestPermissionsResult(int rq, String[] p, int[] g) {
        super.onRequestPermissionsResult(rq, p, g);
        pushPerm();
        if (locWanted) startLoc();
    }
    @Override public void onBackPressed() { /* launcher: stay on Home */ }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopMedia();
        stopLoc();
        web.destroy();
        super.onDestroy();
    }

    // ================= helpers
    private void js(String call) { web.post(() -> web.evaluateJavascript(call, null)); }
    private void jsJson(String fn, JSONObject o) { js("window." + fn + "&&" + fn + "(JSON.parse(" + JSONObject.quote(o.toString()) + "))"); }
    private String label(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }
    private boolean notifAccess() {
        String f = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return f != null && f.contains(getPackageName());
    }
    private boolean hasFine() { return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    private boolean hasCoarse() { return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    private JSONObject permJson() {
        JSONObject o = new JSONObject();
        try { o.put("notif", notifAccess()).put("fine", hasFine()).put("coarse", hasCoarse()); } catch (Exception ignored) { }
        return o;
    }
    private void pushPerm() { jsJson("azPerm", permJson()); }

    // ================= media sessions
    private void startMedia() {
        stopMedia();
        if (!notifAccess()) { pushMedia(); return; }
        try {
            msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            ComponentName cn = new ComponentName(this, MediaListener.class);
            msm.addOnActiveSessionsChangedListener(sessListener, cn, ui);
            setControllers(msm.getActiveSessions(cn));
        } catch (SecurityException e) {
            msm = null;
            pushMedia();
        }
    }
    private void stopMedia() {
        for (MediaController c : ctrls) c.unregisterCallback(ccb);
        ctrls.clear();
        if (msm != null) { try { msm.removeOnActiveSessionsChangedListener(sessListener); } catch (Exception ignored) { } msm = null; }
    }
    private void setControllers(List<MediaController> l) {
        for (MediaController c : ctrls) c.unregisterCallback(ccb);
        ctrls.clear();
        if (l != null) for (MediaController c : l) { ctrls.add(c); c.registerCallback(ccb, ui); }
        pushMedia();
    }
    private MediaController pick() {
        if (!pref.isEmpty()) for (MediaController c : ctrls) if (pref.equals(c.getPackageName())) return c;
        for (MediaController c : ctrls) {
            PlaybackState ps = c.getPlaybackState();
            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) return c;
        }
        for (MediaController c : ctrls) if (c.getMetadata() != null) return c;
        return ctrls.isEmpty() ? null : ctrls.get(0);
    }
    private static String str(MediaMetadata m, String... keys) {
        for (String k : keys) { String v = m.getString(k); if (v != null && !v.isEmpty()) return v; }
        return "";
    }
    private String encodeArt(Bitmap bm) {
        int big = Math.max(bm.getWidth(), bm.getHeight());
        if (big > 400) { float k = 400f / big; bm = Bitmap.createScaledBitmap(bm, Math.round(bm.getWidth() * k), Math.round(bm.getHeight() * k), true); }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 85, o);
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
    }
    private void pushMedia() {
        try {
            JSONObject o = new JSONObject();
            o.put("access", notifAccess()).put("pref", pref);
            JSONArray srcs = new JSONArray();
            for (MediaController c : ctrls) srcs.put(new JSONObject().put("p", c.getPackageName()).put("n", label(c.getPackageName())));
            o.put("srcs", srcs);
            MediaController c = pick();
            if (c == null) { o.put("on", false); jsJson("azMedia", o); return; }
            o.put("on", true).put("pkg", c.getPackageName()).put("src", label(c.getPackageName()));
            MediaMetadata m = c.getMetadata();
            String title = "", artist = "", album = "";
            long dur = 0;
            if (m != null) {
                title = str(m, MediaMetadata.METADATA_KEY_TITLE, MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
                artist = str(m, MediaMetadata.METADATA_KEY_ARTIST, MediaMetadata.METADATA_KEY_ALBUM_ARTIST, MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
                album = str(m, MediaMetadata.METADATA_KEY_ALBUM);
                dur = Math.max(0, m.getLong(MediaMetadata.METADATA_KEY_DURATION));
            }
            o.put("title", title).put("artist", artist).put("album", album).put("dur", dur);
            PlaybackState ps = c.getPlaybackState();
            boolean playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
            long pos = 0; float speed = 1f; boolean canSeek = false;
            if (ps != null) {
                pos = Math.max(0, ps.getPosition());
                speed = ps.getPlaybackSpeed();
                if (playing) pos += (long) ((SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) * speed);
                canSeek = (ps.getActions() & PlaybackState.ACTION_SEEK_TO) != 0;
            }
            o.put("playing", playing).put("pos", pos).put("speed", speed).put("canSeek", canSeek);
            String key = c.getPackageName() + "|" + title + "|" + artist + "|" + album;
            if (!key.equals(lastArtKey)) {
                lastArtKey = key; lastArt = null;
                if (m != null) {
                    Bitmap bm = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    if (bm == null) bm = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (bm == null) bm = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                    String uri = str(m, MediaMetadata.METADATA_KEY_ART_URI, MediaMetadata.METADATA_KEY_ALBUM_ART_URI, MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
                    if (bm == null && uri.startsWith("content://")) {
                        try (InputStream in = getContentResolver().openInputStream(Uri.parse(uri))) { bm = BitmapFactory.decodeStream(in); } catch (Exception ignored) { }
                    }
                    if (bm != null) lastArt = encodeArt(bm);
                    else if (uri.startsWith("https://")) lastArt = "URL:" + uri;
                }
            }
            if (lastArt != null) { if (lastArt.startsWith("URL:")) o.put("artUrl", lastArt.substring(4)); else o.put("art", lastArt); }
            jsJson("azMedia", o);
        } catch (Exception ignored) { }
    }

    // ================= voice guidance (Android TextToSpeech, navigation audio usage + ducking)
    private TextToSpeech tts;
    private boolean ttsReady = false, ttsArabic = false;
    private AudioFocusRequest focusReq;
    private final Map<String, String> launchStatus = new HashMap<>();
    private void initTts() {
        if (tts != null) return;
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) { ttsReady = false; jsTts(); return; }
            int r = tts.setLanguage(new Locale("ar"));
            ttsArabic = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            if (!ttsArabic) tts.setLanguage(Locale.ENGLISH);
            AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            tts.setAudioAttributes(aa);
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(aa).build();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { abandonFocus(); }
                @Override public void onError(String id) { abandonFocus(); }
            });
            ttsReady = true;
            jsTts();
        });
    }
    private void abandonFocus() {
        try { ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).abandonAudioFocusRequest(focusReq); } catch (Exception ignored) { }
    }
    private void jsTts() { try { jsJson("azTts", new JSONObject().put("ready", ttsReady).put("ar", ttsArabic)); } catch (Exception ignored) { } }

    // ================= freeform probe result
    private void pushProbe() {
        String p = getSharedPreferences("az", MODE_PRIVATE).getString("probe", null);
        if (p == null) return;
        try { jsJson("azProbe", new JSONObject(p)); } catch (Exception ignored) { }
    }

    // ================= location (only while the activity is resumed and the map asked for it)
    private void startLoc() {
        stopLoc();
        if (!hasFine() && !hasCoarse()) return;
        try {
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            for (String p : lm.getProviders(true)) {
                if (LocationManager.PASSIVE_PROVIDER.equals(p)) continue;
                lm.requestLocationUpdates(p, 1000, 0, locListener, Looper.getMainLooper());
                Location l = lm.getLastKnownLocation(p);
                if (l != null) pushLoc(l);
            }
        } catch (SecurityException ignored) { }
    }
    private void stopLoc() { if (lm != null) { try { lm.removeUpdates(locListener); } catch (Exception ignored) { } } }
    private void pushLoc(Location l) {
        try { jsJson("azLoc", new JSONObject().put("lat", l.getLatitude()).put("lng", l.getLongitude()).put("acc", l.getAccuracy()).put("spd", l.getSpeed()).put("brg", l.getBearing())); }
        catch (Exception ignored) { }
    }

    private Intent navIntent(String id, String pkg, double lat, double lng) {
        Intent i;
        if ("waze".equals(id)) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://waze.com/ul?ll=" + lat + "," + lng + "&navigate=yes"));
        else if ("google".equals(id)) i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + lat + "," + lng + "&mode=d"));
        else i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng));
        if (pkg != null && !pkg.isEmpty()) i.setPackage(pkg);
        return i;
    }

    private void winResult(boolean ok, String err) {
        try { jsJson("azWin", new JSONObject().put("ok", ok).put("err", err)); } catch (Exception ignored) { }
    }

    // ================= JS bridge (local assets only)
    private class Bridge {
        @JavascriptInterface public void launch(String pkg) {
            runOnUiThread(() -> {
                try { Intent i = getPackageManager().getLaunchIntentForPackage(pkg); if (i != null) startActivity(i); } catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void settings() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public void put(String k, String v) {
            if (k != null && k.startsWith("az.") && v != null && v.length() < 4000000)
                getSharedPreferences("az", MODE_PRIVATE).edit().putString(k, v).apply();
        }
        @JavascriptInterface public String get(String k) {
            return k != null && k.startsWith("az.") ? getSharedPreferences("az", MODE_PRIVATE).getString(k, null) : null;
        }
        @JavascriptInterface public String list() {
            try {
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                JSONArray a = new JSONArray();
                for (ResolveInfo r : getPackageManager().queryIntentActivities(q, 0)) {
                    String p = r.activityInfo.packageName;
                    if (p.equals(getPackageName())) continue;
                    Drawable d = r.loadIcon(getPackageManager());
                    Bitmap bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                    d.setBounds(0, 0, 96, 96); d.draw(new Canvas(bm));
                    ByteArrayOutputStream o = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                    a.put(new JSONObject().put("p", p).put("n", r.loadLabel(getPackageManager()).toString())
                        .put("i", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)));
                }
                return a.toString();
            } catch (Exception e) { return "[]"; }
        }
        // ---- media
        @JavascriptInterface public void mediaCmd(String cmd, long arg) {
            runOnUiThread(() -> {
                MediaController c = pick();
                if (c == null) return;
                MediaController.TransportControls t = c.getTransportControls();
                PlaybackState ps = c.getPlaybackState();
                switch (cmd) {
                    case "toggle": if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play(); break;
                    case "next": t.skipToNext(); break;
                    case "prev": t.skipToPrevious(); break;
                    case "seek": t.seekTo(arg); break;
                    default: break;
                }
            });
        }
        @JavascriptInterface public void mediaSelect(String pkg) { runOnUiThread(() -> { pref = pkg == null ? "" : pkg; pushMedia(); }); }
        @JavascriptInterface public void mediaRefresh() { runOnUiThread(MainActivity.this::startMedia); }
        // ---- permissions / system
        @JavascriptInterface public String perm() { return permJson().toString(); }
        @JavascriptInterface public void reqLoc() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 9));
        }
        @JavascriptInterface public void locOn(boolean on) { runOnUiThread(() -> { locWanted = on; if (on) startLoc(); else stopLoc(); }); }
        @JavascriptInterface public void openNotif() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public void openAppInfo() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public String about() {
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                PackageInfo wv = Build.VERSION.SDK_INT >= 26 ? WebView.getCurrentWebViewPackage() : null;
                return new JSONObject().put("v", pi.versionName).put("code", code).put("sdk", Build.VERSION.SDK_INT)
                    .put("model", Build.MANUFACTURER + " " + Build.MODEL).put("wv", wv == null ? "" : wv.versionName).toString();
            } catch (Exception e) { return "{}"; }
        }
        // ---- maps
        @JavascriptInterface public String mapInfo(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return new JSONObject().put("installed", false).toString();
                PackageInfo pi = getPackageManager().getPackageInfo(pkg, 0);
                return new JSONObject().put("installed", true).put("label", label(pkg)).put("version", pi.versionName)
                    .put("activity", i.getComponent() == null ? "" : i.getComponent().getClassName()).toString();
            } catch (Exception e) { return "{\"installed\":false}"; }
        }
        // ---- A-B style "window in the map card": freeform window with launch bounds (needs OS freeform support)
        @JavascriptInterface public String winCaps() {
            try {
                PackageManager pm = getPackageManager();
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                return new JSONObject().put("sdk", Build.VERSION.SDK_INT)
                    .put("freeformFeature", pm.hasSystemFeature("android.software.freeform_window_management"))
                    .put("freeformSetting", Settings.Global.getInt(getContentResolver(), "enable_freeform_support", 0))
                    .put("forceResizable", Settings.Global.getInt(getContentResolver(), "force_resizable_activities", 0))
                    .put("multiWindow", isInMultiWindowMode()).put("density", dm.density)
                    .put("w", dm.widthPixels).put("h", dm.heightPixels).toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void launchInBounds(String pkg, double l, double t, double r, double b) {
            runOnUiThread(() -> {
                try {
                    Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i == null) { winResult(false, "not_installed"); return; }
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    float d = getResources().getDisplayMetrics().density;
                    Rect rc = new Rect(Math.round((float) l * d), Math.round((float) t * d), Math.round((float) r * d), Math.round((float) b * d));
                    ActivityOptions o = ActivityOptions.makeBasic();
                    o.setLaunchBounds(rc);
                    startActivity(i, o.toBundle());
                    winResult(true, "");
                } catch (Exception e) { winResult(false, String.valueOf(e.getMessage())); }
            });
        }
        // ---- voice
        @JavascriptInterface public void ttsInit() { runOnUiThread(MainActivity.this::initTts); }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                initTts();
                if (!ttsReady || text == null) return;
                try { ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).requestAudioFocus(focusReq); } catch (Exception ignored) { }
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav");
            });
        }
        // ---- real freeform test: launches our own probe activity with bounds and measures the window it actually got
        @JavascriptInterface public void probeFreeform(double l, double t, double r, double b) {
            runOnUiThread(() -> {
                try {
                    float d = getResources().getDisplayMetrics().density;
                    Rect rc = new Rect(Math.round((float) l * d), Math.round((float) t * d), Math.round((float) r * d), Math.round((float) b * d));
                    getSharedPreferences("az", MODE_PRIVATE).edit().putString("probe", new JSONObject().put("pending", true)
                        .put("rw", rc.width()).put("rh", rc.height()).toString()).apply();
                    Intent i = new Intent(MainActivity.this, ProbeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ActivityOptions o = ActivityOptions.makeBasic();
                    o.setLaunchBounds(rc);
                    startActivity(i, o.toBundle());
                } catch (Exception e) {
                    try { jsJson("azProbe", new JSONObject().put("error", String.valueOf(e.getMessage()))); } catch (Exception ignored) { }
                }
            });
        }
        // ---- navigation apps: per-app diagnostics + destination hand-off (full screen)
        @JavascriptInterface public String navApps(String hudhudPkg) {
            try {
                JSONArray a = new JSONArray();
                String[][] defs = {{"google", "com.google.android.apps.maps"}, {"waze", "com.waze"}, {"hudhud", hudhudPkg == null ? "" : hudhudPkg}};
                for (String[] dfn : defs) {
                    String pkg = dfn[1];
                    JSONObject o = new JSONObject().put("id", dfn[0]).put("pkg", pkg);
                    boolean inst = !pkg.isEmpty() && getPackageManager().getLaunchIntentForPackage(pkg) != null;
                    o.put("installed", inst);
                    if (inst) {
                        Intent dl = navIntent(dfn[0], pkg, 24.7136, 46.6753);
                        o.put("deepLink", dl.resolveActivity(getPackageManager()) != null);
                        o.put("version", getPackageManager().getPackageInfo(pkg, 0).versionName);
                    }
                    o.put("lastLaunch", launchStatus.containsKey(dfn[0]) ? launchStatus.get(dfn[0]) : "");
                    a.put(o);
                }
                return a.toString();
            } catch (Exception e) { return "[]"; }
        }
        @JavascriptInterface public void navGo(String id, String pkg, double lat, double lng) {
            runOnUiThread(() -> {
                try {
                    Intent i = (lat == 0 && lng == 0) ? getPackageManager().getLaunchIntentForPackage(pkg) : navIntent(id, pkg, lat, lng);
                    if (i == null) throw new IllegalStateException("no_intent");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    launchStatus.put(id, "ok");
                } catch (Exception e) { launchStatus.put(id, "fail: " + e.getMessage()); }
                try { jsJson("azNavLaunch", new JSONObject().put("id", id).put("status", launchStatus.get(id))); } catch (Exception ignored) { }
            });
        }
        // ---- default launcher (HOME role)
        @JavascriptInterface public boolean isHome() {
            ResolveInfo ri = getPackageManager().resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY);
            return ri != null && getPackageName().equals(ri.activityInfo.packageName);
        }
        @JavascriptInterface public void pickHome() {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 8);
                            return;
                        }
                    }
                    startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
                }
            });
        }
        @JavascriptInterface public void navTo(double lat, double lng, String pkg) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng));
                    if (pkg != null && !pkg.isEmpty() && getPackageManager().getLaunchIntentForPackage(pkg) != null) i.setPackage(pkg);
                    startActivity(i);
                } catch (Exception ignored) { }
            });
        }
    }
}
