package com.azdrive.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER_REQUEST = 7001;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(), "AZ");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        web.setBackgroundColor(0xFF050B1F);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override public void onWindowFocusChanged(boolean focus) { super.onWindowFocusChanged(focus); if (focus) applyImmersive(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); applyImmersive(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER_REQUEST && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() { /* Keep the launcher on its dashboard. */ }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) { web.removeJavascriptInterface("AZ"); web.destroy(); web = null; }
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void launch(String packageName) {
            if (packageName == null || packageName.trim().isEmpty()) return;
            runOnUiThread(() -> {
                try { Intent i = getPackageManager().getLaunchIntentForPackage(packageName); if (i != null) startActivity(i); }
                catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void put(String key, String value) {
            if (key != null && key.startsWith("az.") && value != null && value.length() < 4_000_000)
                getSharedPreferences("az", MODE_PRIVATE).edit().putString(key, value).apply();
        }
        @JavascriptInterface public String get(String key) {
            return key != null && key.startsWith("az.") ? getSharedPreferences("az", MODE_PRIVATE).getString(key, null) : null;
        }
        @JavascriptInterface public void settings() {
            runOnUiThread(() -> { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { } });
        }
        @JavascriptInterface public String list() {
            try {
                Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                JSONArray apps = new JSONArray();
                for (ResolveInfo r : getPackageManager().queryIntentActivities(query, 0)) {
                    if (r.activityInfo == null) continue;
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    Drawable icon = r.loadIcon(getPackageManager());
                    Bitmap bitmap = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    icon.setBounds(0, 0, 96, 96);
                    icon.draw(canvas);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    apps.put(new JSONObject().put("p", pkg)
                        .put("n", r.loadLabel(getPackageManager()).toString())
                        .put("i", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)));
                    bitmap.recycle();
                }
                return apps.toString();
            } catch (Exception e) { return "[]"; }
        }
    }
}
