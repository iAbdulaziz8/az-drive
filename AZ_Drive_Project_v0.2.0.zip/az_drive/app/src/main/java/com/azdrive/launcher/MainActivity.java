package com.azdrive.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); // Required for bundled android_asset resources.
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AZ");
        web.setBackgroundColor(0xFF050B1F);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) applyImmersive();
    }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); applyImmersive(); }
    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override public void onBackPressed() { /* Keep the launcher on its dashboard. */ }
    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AZ"); web.destroy(); web = null; }
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void launch(String packageName) {
            if (packageName == null || packageName.trim().isEmpty()) return;
            runOnUiThread(() -> {
                try {
                    Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (intent != null) startActivity(intent);
                } catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void settings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void apps() {
            runOnUiThread(() -> showInstalledApps());
        }
    }

    private void showInstalledApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = pm.queryIntentActivities(query, 0);
        Collections.sort(resolved, Comparator.comparing(
            r -> String.valueOf(r.loadLabel(pm)), String.CASE_INSENSITIVE_ORDER));
        List<ResolveInfo> apps = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (ResolveInfo r : resolved) {
            if (r.activityInfo == null || getPackageName().equals(r.activityInfo.packageName)) continue;
            apps.add(r);
            labels.add(String.valueOf(r.loadLabel(pm)));
        }
        if (labels.isEmpty()) labels.add("لا توجد تطبيقات قابلة للتشغيل");
        new AlertDialog.Builder(this).setTitle("التطبيقات")
            .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                if (which < apps.size()) {
                    String pkg = apps.get(which).activityInfo.packageName;
                    Intent launch = pm.getLaunchIntentForPackage(pkg);
                    if (launch != null) startActivity(launch);
                }
            }).setNegativeButton("إغلاق", null).show();
    }
}
