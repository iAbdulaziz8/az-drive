package com.azdrive.launcher;

import android.content.ComponentName;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.service.notification.NotificationListenerService;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Reads real active MediaSession data. Requires user-enabled Notification Access. */
public class AZNotificationListener extends NotificationListenerService {
    private static volatile AZNotificationListener instance;
    private MediaSessionManager manager;
    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
        controllers -> { active = controllers == null ? Collections.emptyList() : controllers; };
    private static volatile List<MediaController> active = Collections.emptyList();

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        manager = (MediaSessionManager)getSystemService(MEDIA_SESSION_SERVICE);
        try {
            ComponentName component = new ComponentName(this, AZNotificationListener.class);
            manager.addOnActiveSessionsChangedListener(sessionsListener, component);
            List<MediaController> list = manager.getActiveSessions(component);
            active = list == null ? Collections.emptyList() : list;
        } catch (Exception e) { Log.w("AZDrive", "Media session listener unavailable", e); }
    }

    @Override public void onListenerDisconnected() {
        try { if (manager != null) manager.removeOnActiveSessionsChangedListener(sessionsListener); }
        catch (Exception ignored) {}
        active = Collections.emptyList();
        instance = null;
        super.onListenerDisconnected();
    }

    @Override public void onDestroy() {
        active = Collections.emptyList();
        instance = null;
        super.onDestroy();
    }

    private static MediaController current() {
        List<MediaController> list = active;
        if (list == null || list.isEmpty()) {
            AZNotificationListener s = instance;
            if (s != null && s.manager != null) {
                try {
                    list = s.manager.getActiveSessions(new ComponentName(s, AZNotificationListener.class));
                    active = list == null ? Collections.emptyList() : list;
                } catch (Exception ignored) {}
            }
        }
        if (list == null) return null;
        MediaController best = null;
        long bestScore = Long.MIN_VALUE;
        for (MediaController c : list) {
            if (c == null) continue;
            PlaybackState p = c.getPlaybackState();
            long score = p == null ? 0 : p.getState() == PlaybackState.STATE_PLAYING ? 1000000 :
                p.getState() == PlaybackState.STATE_BUFFERING ? 500000 : p.getState() == PlaybackState.STATE_PAUSED ? 100000 : 0;
            if (p != null) score += Math.max(0, p.getLastPositionUpdateTime());
            if (score > bestScore) { best = c; bestScore = score; }
        }
        return best;
    }

    private static String encodeArtwork(Bitmap source) {
        if (source == null) return "";
        try {
            int max = 420;
            float scale = Math.min(1f, (float)max / Math.max(source.getWidth(), source.getHeight()));
            Bitmap scaled = scale < 1f ? Bitmap.createScaledBitmap(source,
                Math.max(1, Math.round(source.getWidth()*scale)),
                Math.max(1, Math.round(source.getHeight()*scale)), true) : source;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 84, out);
            if (scaled != source) scaled.recycle();
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    public static String stateJson() {
        AZNotificationListener s = instance;
        if (s == null) return "{\"available\":false,\"reason\":\"notification_access_disabled\"}";
        try {
            MediaController c = current();
            if (c == null) return "{\"available\":true,\"playing\":false,\"title\":\"\",\"artist\":\"\"}";
            MediaMetadata m = c.getMetadata();
            PlaybackState p = c.getPlaybackState();
            JSONObject o = new JSONObject();
            String title = "", artist = "", album = "", art = "";
            long duration = 0;
            if (m != null) {
                title = String.valueOf(m.getText(MediaMetadata.METADATA_KEY_TITLE) == null ? "" : m.getText(MediaMetadata.METADATA_KEY_TITLE));
                artist = String.valueOf(m.getText(MediaMetadata.METADATA_KEY_ARTIST) == null ? "" : m.getText(MediaMetadata.METADATA_KEY_ARTIST));
                album = String.valueOf(m.getText(MediaMetadata.METADATA_KEY_ALBUM) == null ? "" : m.getText(MediaMetadata.METADATA_KEY_ALBUM));
                duration = Math.max(0, m.getLong(MediaMetadata.METADATA_KEY_DURATION));
                Bitmap b = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (b == null && m.getDescription() != null) b = m.getDescription().getIconBitmap();
                art = encodeArtwork(b);
            }
            String app = c.getPackageName();
            String appLabel = app;
            try { ApplicationInfo ai = s.getPackageManager().getApplicationInfo(app, 0); appLabel = s.getPackageManager().getApplicationLabel(ai).toString(); }
            catch (Exception ignored) {}
            long position = p == null ? 0 : Math.max(0, p.getPosition());
            boolean playing = p != null && p.getState() == PlaybackState.STATE_PLAYING;
            o.put("available", true); o.put("package", app); o.put("source", appLabel);
            o.put("title", title); o.put("artist", artist); o.put("album", album);
            o.put("artwork", art); o.put("duration", duration); o.put("position", position);
            o.put("playing", playing); o.put("state", p == null ? "none" : p.getState());
            o.put("actions", p == null ? 0 : p.getActions());
            return o.toString();
        } catch (Exception e) {
            Log.w("AZDrive", "Unable to read media metadata", e);
            return "{\"available\":true,\"error\":true}";
        }
    }

    public static void seekTo(long ms) {
        MediaController c = current(); if (c == null) return;
        try { c.getTransportControls().seekTo(Math.max(0, ms)); } catch (Exception e) { Log.w("AZDrive", "seek failed", e); }
    }

    private static boolean shuffleEnabled = false;
    private static boolean repeatEnabled = false;

    public static void control(String action) {
        MediaController c = current(); if (c == null || action == null) return;
        try {
            MediaController.TransportControls t = c.getTransportControls();
            switch (action) {
                case "play": t.play(); break;
                case "pause": t.pause(); break;
                case "toggle":
                    PlaybackState p = c.getPlaybackState();
                    if (p != null && p.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
                    break;
                case "next": t.skipToNext(); break;
                case "previous": t.skipToPrevious(); break;
                case "shuffle":
                    if (android.os.Build.VERSION.SDK_INT >= 26) {
                        shuffleEnabled = !shuffleEnabled;
                        t.setShuffleMode(shuffleEnabled ? PlaybackState.SHUFFLE_MODE_ALL : PlaybackState.SHUFFLE_MODE_NONE);
                    }
                    break;
                case "repeat":
                    if (android.os.Build.VERSION.SDK_INT >= 26) {
                        repeatEnabled = !repeatEnabled;
                        t.setRepeatMode(repeatEnabled ? PlaybackState.REPEAT_MODE_ALL : PlaybackState.REPEAT_MODE_NONE);
                    }
                    break;
            }
        } catch (Exception e) { Log.w("AZDrive", "Media control failed: " + action, e); }
    }
}
