package com.azdrive.launcher;

import android.service.notification.NotificationListenerService;

/** User-enabled notification access endpoint. Media-session integration is added separately. */
public class AZNotificationListener extends NotificationListenerService {
    @Override public void onListenerConnected() { super.onListenerConnected(); }
}
