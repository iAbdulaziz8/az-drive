# AZ Drive — MapLibre Native + Valhalla technical status

## Decision
Use MapLibre Native Android for the map renderer and Valhalla for routing/maneuver data. Do not use Leaflet. The map is a native Android `MapView` layered over the existing HTML dashboard map viewport; the rest of the dashboard remains in the existing WebView.

## Source changes in this milestone
- Added MapLibre Native Android OpenGL SDK dependency `org.maplibre.gl:android-sdk-opengl:13.6.1`.
- Added native map lifecycle management and layout synchronization with the `#azmap` viewport.
- Added OpenFreeMap Liberty style URL.
- Added native map destination selection and map marker layers.
- Added Nominatim place search and Android LocationManager current-location flow.
- Added Valhalla `/route` POST request using `costing=auto`, Arabic narrative language, and kilometer units.
- Added polyline6 decoding and native route-line rendering.
- Added maneuver text extraction and an Arabic dashboard guidance strip.
- Removed Leaflet script/style CDN references and removed OSRM routing implementation.

## Architecture constraints / risks
- The public Valhalla endpoint and public Nominatim endpoint are development conveniences only. They are not guaranteed services and may rate-limit or change. A production rollout should use a managed or self-hosted geocoder and Valhalla deployment.
- OpenFreeMap style/tiles availability, attribution, caching and terms must be reviewed before relying on it in a product. OpenStreetMap attribution remains visible.
- The OpenGL renderer is selected to reduce Vulkan compatibility risk on automotive head units. Actual GPU/driver compatibility remains unverified on the target Carlinkit firmware.
- The native MapView overlays the HTML map viewport. Different screen densities, split-screen/window insets and editor layout changes require on-device verification.

## Not yet complete — do not describe as full navigation
- Continuous GPS tracking along the route, current maneuver progression and spoken turn-by-turn guidance.
- Off-route detection and automatic rerouting.
- Route alternatives, destination autocomplete, saved places and robust search result selection.
- Offline map region downloads and offline routing graph.
- Traffic-aware routing, speed-limit data, lane guidance and camera/road-hazard data.
- Production endpoint deployment, quotas, privacy policy and reliability monitoring.

## Validation status
- Leaflet CDN references removed from dashboard HTML.
- XML and JavaScript syntax checks should be run before packaging.
- Android build and Carlinkit device runtime tests have not been performed in this environment. A GitHub Actions build is required after upload; successful compilation still does not prove device compatibility.
