# AZ Drive — Phase 3d source update

## Baseline and scope
- Source baseline: Build 26 project archive (`AZ_Drive_Phase3c.zip`), retained as the project structure.
- Work is source-level only. The repository `main` branch was not changed by this local package.
- This package is not an APK.

## Implemented in this source snapshot
- Replaced the map placeholder with an interactive Leaflet map using OpenStreetMap tiles.
- Added place search through Nominatim, current-location request through WebView geolocation, map-point selection, and driving route preview through OSRM.
- Added visible OpenStreetMap attribution.
- Added native `NotificationListenerService` / `MediaSessionManager` reading of real active sessions, metadata, album art, playback status, and transport/seek controls.
- Added album artwork display, media source/title/artist, duration/progress, and controls to the dashboard.
- Added bundled day/night Riyadh backgrounds and nature/coast presets, with independent day/night selection and existing custom-image upload support.
- Removed the top header row, expanded the map across the dashboard height, and centered the date line.

## Partially implemented / limitations
- The map is a real online interactive map, but it is not an embedded Google Maps or HudHud native app. Route preview depends on public community endpoints and is not turn-by-turn voice navigation. Production use should review service terms, rate limits, availability and possible self-hosted/paid routing/geocoding.
- The media UI polls native session state every second; artwork is resized to 420 px before transfer. Actual app-specific metadata availability depends on each media app's MediaSession implementation.
- Built-in backgrounds are included as local assets; custom uploads continue to use the existing local preference mechanism. Crop preview/gallery polish is not complete.
- The existing editor's full undo/redo, import/export profiles, drag/drop and all advanced per-card controls are not yet complete.

## Verification performed
- AndroidManifest XML parses successfully.
- Inline JavaScript passes `node --check`.
- ZIP structure and required source assets are included.
- No Android SDK or Gradle executable is installed in this execution environment, so Android compilation was not run.
- No Carlinkit device is attached; no runtime/device test is claimed.

## Carlinkit validation checklist
1. Install a build produced by GitHub Actions on the TBox Ultra Android 15.
2. Confirm WebView internet access and that OSM tiles load; verify attribution.
3. Search a place, tap a map point, enable location permission, and test route preview.
4. Enable AZ Drive Notification Access in Android settings; if Android blocks access for a sideloaded app, use App info > menu > Allow restricted settings (wording may vary), then enable Notification Access.
5. Start Spotify/YouTube Music/other media, confirm real title/artist/artwork and all transport controls.
6. Test switching between two media apps and resuming a paused session.
7. Switch day/night themes and verify independent backgrounds persist after force-stop/reboot.
8. Verify dashboard fit, touch targets, and legibility at the device's native landscape resolution.
\n\n## Phase 3f visual corrections\n- Removed Riyadh day/night images as automatic defaults; dashboard now starts with its theme gradient until user selects a background.\n- Added a persistent AZ Drive settings shortcut inside the bottom dock.\n- Refined media card hierarchy, artwork size, title/artist truncation, progress bar and playback controls without replacing native media data.\n- Increased the top dashboard row share slightly to improve vertical card balance.\n