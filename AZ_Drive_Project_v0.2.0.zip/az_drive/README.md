# AZ Drive – Phase 3b (Claude Editor v2 integration)

This archive combines the complete Android/Gradle project from Phase 3a with the latest dashboard HTML and Android bridge supplied in `az_drive_phase2(2).zip`.

## Included
- Complete Android Gradle project and manifest.
- Latest four-tab customization editor (Colors, Layout, Icons, General).
- Clock style selection and per-card controls as implemented in the supplied HTML.
- WebView-to-Android bridge for persistent `az.*` preferences, installed-app listing/launching, system settings, and image selection.
- Immersive landscape launcher behavior.

## Validation status
- Archive integrity and required project files: checked.
- Inline JavaScript syntax: checked separately before upload.
- Gradle build: must be confirmed by GitHub Actions for this exact archive.
- Carlinkit TBox Ultra device testing: not yet performed.

## Known limitations
- Google Maps remains a placeholder in the supplied UI.
- MediaSession integration is not implemented by this change.
- Drag-and-drop card positioning and full geometry editor are not verified as implemented.
- A high-resolution built-in Riyadh skyline asset is not included.
- Do not treat UI controls as verified until tested on the target device.


## Phase 3c

- Added an in-dashboard permissions panel.
- Added runtime approximate/precise location permission request; manual city selection does not require location access.
- Declared a user-enabled NotificationListenerService entry and a shortcut to Android Notification Access settings. This is permission plumbing only; media-session metadata/control integration is not yet implemented.
- Added Google Maps installation detection. It intentionally does not claim that the installed app can be embedded.
- Google Maps cross-app embedding requires the target app to opt in; validate on the actual Carlinkit firmware before deciding whether a true embedded map is possible.
- No Maps SDK/API key or Maps Platform billing configuration is added.

### Validation

- AndroidManifest.xml parses as valid XML.
- Dashboard JavaScript passes `node --check`.
- A Gradle/Android build and on-device permission-flow test are still required.


## Phase 3d integration update (source-level; device validation pending)

- Map card now uses an interactive Leaflet/OpenStreetMap view, Nominatim place search, browser geolocation, and OSRM route preview. It requires internet access. OSM/Nominatim/OSRM are community services with usage policies and are not a guaranteed production navigation SLA; attribution is displayed. This is not embedded Google Maps or Hudhud.
- Native media integration now reads active Android MediaSession controllers through `NotificationListenerService`, exposes title/artist/album/duration/position/artwork, and forwards play/pause/next/previous/seek. User must explicitly enable Notification Access. The WebView refreshes media state every second.
- Added bundled day/night Riyadh and nature background presets based on the supplied references, plus custom upload support already present in the project. Built-in presets are selected independently for day and night and saved through the existing native preference bridge.
- Dashboard grid removes the top header row and expands the map across both dashboard rows; date is centered. User assets are kept in app assets.
- Build and on-device testing are not claimed here. Verify Android 15 notification access, WebView geolocation, external tile connectivity, map attribution, routing limits, and media-session behavior on the actual Carlinkit TBox Ultra.

## Native maps (Phase 3e — implementation in progress)

The dashboard map card is now rendered by MapLibre Native for Android (OpenGL renderer for broader automotive-device compatibility); Leaflet and its CDN dependencies have been removed. The native `MapView` is positioned over the dashboard map viewport while the existing WebView continues to render the rest of the dashboard. Search is geocoded with Nominatim, map taps select a destination, Android location provides the current position, and route geometry plus maneuver instructions are requested from Valhalla and rendered natively.

Current development endpoints:
- Style: `https://tiles.openfreemap.org/styles/liberty`
- Geocoding: Nominatim public search endpoint
- Routing: `https://valhalla1.openstreetmap.de/route`

These are public/community services, not a production SLA. Before public or sustained deployment, replace them with contracted/managed services or self-hosted infrastructure, review usage policies, attribution, data freshness, regional coverage and service limits. Map display and route planning are implemented as a native foundation; continuous off-route detection, automatic rerouting, voice-guidance progression, speed-limit/traffic data and offline regional maps remain to be completed and validated on the TBox Ultra.
