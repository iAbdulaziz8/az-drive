# AZ Drive — Car launcher prototype

Target device: Carlinkit TBox Ultra (Android 15, as reported by the owner).

## Included
- Android HOME/DEFAULT launcher intent filter.
- Landscape dashboard with a black/navy palette and cyan accents.
- Immersive full-screen mode for an in-car display; system bars can be temporarily revealed with an edge swipe where supported by the firmware.
- Riyadh weather from Open-Meteo (no API key).
- Riyadh prayer countdown from AlAdhan using calculation method 4 (Umm al-Qura).
- Shortcuts to Google Maps, Brave, YouTube Music, YouTube, and an installed-app picker.
- Layout uses weighted panels so it can adapt to different landscape aspect ratios; exact appearance still needs testing on the target screen.

## Important behavior and limitations
- This is an early prototype, not a production-verified launcher.
- To start AZ Drive automatically after boot, Android must allow it to be selected as the default Home app. When the system launches the default Home app after boot, AZ Drive opens. This project intentionally does not use a background boot receiver to force-open an Activity.
- It launches other apps; it does not embed third-party app windows inside its own UI. Maps + video side-by-side depends on the TBox firmware's split-screen/multi-window support.
- Thmanyah can be opened from the installed-app picker if installed; its package name is not assumed.
- Weather and prayer data require internet. Prayer calculation is requested using AlAdhan method 4; verify timings against the local authority before relying on them.
- Default launcher selection, immersive behavior, and app launching must be tested on the actual TBox. Keep the original launcher available as a fallback.

## Build requirements
- Android SDK Platform 35 and Build Tools 35.0.0
- JDK 17 or newer
- Android Gradle Plugin 8.7.3 (Gradle 8.9)

Build with Android Studio using **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `gradle assembleDebug` from this project root in an environment with Gradle 8.9 configured.

## Install
Install the generated `app-debug.apk` on the TBox. Press Home and choose AZ Drive, then choose **Always** if Android offers that option. If the firmware does not show AZ Drive in the Home-app chooser, the launcher role may be restricted by the device firmware.

## Safety
Do not disable Play Protect or grant Accessibility/notification permissions to this prototype. It does not require those permissions.


## Phase 3a integration (2026-11-26)
- The supplied Phase 2/3a HTML dashboard is bundled at `app/src/main/assets/index.html`.
- `MainActivity` hosts it in a WebView and exposes `AZ.launch`, `AZ.settings`, and `AZ.apps`.
- `AZ.apps` opens a native list of installed launcher activities; selecting one launches it.
- The previous native dashboard implementation is preserved as `LegacyDashboardActivity.java`.
- The supplied web editor stores card settings/profiles in browser local storage.

Not yet implemented/verified: Android MediaSession controls, embedded Google Maps, drag/resize layout editor, image background picker, and device-specific validation on Carlinkit TBox Ultra. This project still requires a successful Android Gradle build and on-device test before release.
