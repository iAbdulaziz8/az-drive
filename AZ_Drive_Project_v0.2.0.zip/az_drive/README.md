# AZ Drive – Phase 3b (Claude Editor v2 integration)

This archive combines the complete Android/Gradle project from Phase 3a with the latest dashboard HTML and Android bridge supplied in `az_drive_phase2(2).zip`.

## Included
- Complete Android Gradle project and manifest.
- Latest four-tab customization editor (Colors, Layout, Icons, General).
- Clock style selection and per-card controls as implemented in the supplied HTML.
- WebView-to-Android bridge for persistent `az.*` preferences, installed-app listing/launching, system settings, and image selection.
- Immersive landscape launcher behavior.

## Validation status
- Archive integrity and required project files: checked.
- Inline JavaScript syntax: checked separately before upload.
- Gradle build: must be confirmed by GitHub Actions for this exact archive.
- Carlinkit TBox Ultra device testing: not yet performed.

## Known limitations
- Google Maps remains a placeholder in the supplied UI.
- MediaSession integration is not implemented by this change.
- Drag-and-drop card positioning and full geometry editor are not verified as implemented.
- A high-resolution built-in Riyadh skyline asset is not included.
- Do not treat UI controls as verified until tested on the target device.
