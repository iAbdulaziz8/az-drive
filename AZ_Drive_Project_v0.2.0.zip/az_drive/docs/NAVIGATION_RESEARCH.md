# AZ Drive – Navigation options (research, Session 4)
Legend: [S] = checked in official documentation/search during this session; [K] = from my general knowledge, NOT re-verified now; [T] = tested.

## What the device already told us
- The TBox firmware did not allow the A-B style "external app inside the card": the owner's photo shows the freeform-not-supported message. A real probe (`ProbeActivity`, Editor › Maps › "اختبار النوافذ الحرة") now measures what window the firmware actually grants; result pending on device.
- Android cannot render another app's Activity inside a WebView or a normal view. Activity Embedding only works for activities the host owns or that opt in; VirtualDisplay/ActivityView require system privileges. [K]

## Comparison
| Option | Navigation (turn-by-turn, voice, reroute) | Inside the Map card? | Needs | Cost / licence | Verdict |
|---|---|---|---|---|---|
| **Google Navigation SDK for Android** | Yes: Google turn-by-turn UI, traffic, rerouting [S] | Yes, as a native `NavigationView` (a native view, not WebView; card area must become a native view overlay) | Google Cloud project, API key with `navigationsdk.googleapis.com` enabled, billing account, terms dialog in app; replaces the Maps SDK dependency; v8+ needs AGP 9.0.1 (project uses 8.7.3 → use a 7.x release) [S]. Eligibility/Google Play services on the TBox: not verified | Pay per destination; first 1,000 destinations/month free; no extra charge for reroutes/traffic [S]. Exact price list: see Google's price list | **Best product, blocked on your credentials + billing approval.** Not implemented (cannot be built/tested without a key). |
| Google Maps app via intent | Full Google navigation, but in the Google Maps app | No (full-screen) | Installed app | Free | Implemented as hand-off (`google.navigation:`), full-screen. [T in browser only] |
| **Waze** | Only deep links that open the Waze app and start navigation (`waze.com/ul?ll=..&navigate=yes`) [S]; no embedding SDK found | No | Installed app | Free | Implemented as hand-off. |
| **HudHud** | Public GitHub org shows forks of MapLibre Navigation Android and GraphHopper [S]; no public SDK/licence documentation found in my search | Unknown | Contact HudHud for SDK/API access | Unknown | Detected by label; launched through a `geo:` intent with its package. No embedding claimed. |
| Mapbox / HERE / TomTom navigation SDKs | Yes (commercial turn-by-turn SDKs) [K] | Yes (native views) | Access tokens/keys, accounts | Paid beyond free tiers [K] – not verified this session | Candidates if you prefer them to Google; need your account. |
| **Open-source engine (implemented)** | Real GPS + OSRM route steps + AZ guidance logic: next-maneuver banner, distance, ETA, remaining distance/time, speed, heading-up, auto-follow, voice (Android TextToSpeech), deviation detection + reroute, route alternatives, GPS-loss warning | **Yes, inside the Map card** | Internet for tiles/routing; GPS. No key | Free; public OSM/Nominatim/OSRM servers have usage policies (personal use only) [K]. Routing URL is configurable (`S.nav.osrm`) so you can point it to your own OSRM/Valhalla/GraphHopper server | **Chosen now.** |

## Limits of the chosen solution (be aware)
- No live traffic and no lane guidance; routes use OSM data via the public OSRM demo server (reliability not guaranteed).
- Map matching is simple snapping to the route line (no road-network matching).
- Voice quality depends on the TBox TextToSpeech engine; Arabic voice data may be missing (the Maps tab shows the real status; English phrases are used when Arabic is unavailable).
- Tiles need internet; there is no offline map.
- Whether the TBox has a GPS receiver and gives accurate fixes is unknown until tested.

## What I need from you to go to the Google Navigation SDK
1. A Google Cloud project with billing enabled and an API key restricted to this app, with Navigation SDK enabled.
2. Approval to use a 7.x SDK release with the current Gradle plugin (or to upgrade AGP).
3. Confirmation that Google Play services exist on the TBox.
