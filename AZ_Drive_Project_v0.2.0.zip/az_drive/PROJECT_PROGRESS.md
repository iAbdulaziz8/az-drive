# AZ Drive – PROJECT_PROGRESS.md
_Session 4 update appended below the original sections; latest status is in "SESSION 4"._
Branch to use: `feature/phase-2-webview-dashboard` (never `main`, never merge PR #1).
Version in this drop: 0.3.1 (versionCode 4). Last session: Session 3 – Phase "Map window (A-B style)" + regression fixes.

## Verification levels (read this first)
- **B** = verified in a desktop browser with a *simulated* native bridge (Playwright). Not Android.
- **C** = compiled by Gradle / GitHub Actions. **NOT DONE for this drop** (no Android SDK in the authoring environment). Java was only checked by brace balance.
- **D** = tested on the Carlinkit TBox Ultra. **NOT DONE for anything in this drop.** (Earlier builds up to the editor v2 were run on the device by the owner: dashboard, weather, prayer times, day background upload.)

## Completed (B only unless stated)
- Layout: top header (location/temperature) removed; cards start at the same top as the rail; larger map card; dock kept at the bottom; gap row above dock for the skyline.
- Clock: 24h digital + analog, Gregorian + Hijri, centered date, faces/styles/size editor. Fix this session: digital+analog fit on one row (container units).
- Prayer times: AlAdhan, 5 prayers + sunrise, next-prayer highlight, live countdown, daily refresh, settings (city, country, method, Asr school, minute adjustment). 
- Weather: Open-Meteo (temp, condition, hi/lo, feels-like, humidity, wind + direction, UV, rain %), AQI (Open-Meteo air quality), last-update time, cached when offline.
- Day/Night/Auto using Riyadh sunrise/sunset; per-theme accent; per-theme backgrounds.
- Backgrounds: supplied Riyadh day/night + 2 mountain photos, 3 generated "design" wallpapers, gallery with preview/apply/cancel, custom upload (day/night separately), position/zoom/brightness/blur/opacity, horizon auto-align above the dock.
- Editor (9 tabs): colors, backgrounds, layout (presets, per-card size via grid tracks, swap position, lock, hide), icons (size, stroke, shape, dock add/remove/reorder), maps, media source, permissions, general (fonts, 12/24h, date visibility, prayer settings, profiles, import/export), about. Undo/redo, reset card/all, persistence (localStorage + native SharedPreferences mirror).
- Dock: real installed-app icons through PackageManager (Java `list()`), add/remove/reorder.
- Media card: renders real MediaSession data pushed by Java (title, artist, album, art, source, progress, elapsed/remaining, play/pause, next/previous, ±15s seek, tap-to-seek, source selection). Fix this session: a duplicate function name had silently prevented the media card from updating.
- Map card: embedded interactive OpenStreetMap map (drag, pinch/wheel zoom, search via Nominatim, route via OSRM, distance/ETA, location marker when Java sends it). Night mode = dark-filtered tiles.
- Map card A-B style window (this session): provider switch ⇄ (AZ map / Google Maps / Waze / HudHud) *inside the map card only*; external providers launch through `ActivityOptions.setLaunchBounds` with the card rectangle; fallback = full-screen launch. Diagnostics in Editor › Maps (installed apps, freeform capability).

## Partially completed
- MediaSession: Java side written (MediaSessionManager + NotificationListenerService `MediaListener`), **uncompiled and untested on device**. Shuffle/repeat removed (not exposed by the framework controller API). Brave metadata depends on what Brave publishes.
- Location on the map: Java LocationManager bridge written, uncompiled/untested; the TBox may have no GPS.
- Permissions screen: status + links (location request, notification listener settings, app info for restricted-settings on Android 13+). Untested on device.
- Layout editing: sizes are grid-track based (shared by cards in the same row/column); swap instead of free drag-and-drop.

## Blocked / cannot be promised
- **Embedding another app's Activity inside the WebView card is not possible on stock Android.** Activity Embedding (Jetpack WindowManager) only works for activities the host owns or that opt in with `allowUntrustedActivityEmbedding`; VirtualDisplay/ActivityView need system privileges.
- The A-B-style card window depends on the firmware supporting freeform windows. If it does not, the app opens full screen. Existing task windows are not re-positioned by a second launch. Only the device test can tell.
- Google Maps JS/SDK and HudHud SDK were NOT integrated (keys/billing/licensing need an owner decision).
- No Riyadh photo can be generated; supplied photos are used.

## Pending (not started)
- Sidebar: car button action; Android System Settings shortcut in the sidebar; AZ settings shortcut placed in the dock position agreed with the owner (currently the rail "الإعدادات" opens the AZ editor).
- Weather location editor (only prayer city is configurable).
- True drag-and-drop layout editing; changing glyph sets for dashboard icons.
- Turn-by-turn navigation (use the external provider).

## Known bugs / risks
- Gradle build of this drop not yet run: possible Java compile errors (API usage written without a compiler). Send the Actions log for fixing.
- OSM tile/Nominatim/OSRM public servers have usage policies; fine for personal use, not for distribution.
- The tile map flashes blank for a moment when changing zoom level.

## Files modified in this drop (relative to v0.2.0)
app/src/main/assets/index.html (rewritten UI), app/src/main/assets/bg/* (new), app/src/main/java/com/azdrive/launcher/MainActivity.java (rewritten), MediaListener.java (new), app/src/main/AndroidManifest.xml (listener service, location permissions, singleTask, resizeableActivity), app/build.gradle (0.3.1 / 4), PROJECT_PROGRESS.md.

## Latest build status
Not built (no SDK here). Last owner-confirmed build on the device: Build #26 (earlier code).

## Exact next step
1. Commit this drop on `feature/phase-2-webview-dashboard`; run the Actions build; paste any compile errors back.
2. Device checklist: (a) notification access → play Spotify/YouTube/Brave and watch the media card; (b) Editor › Maps › فحص إمكانية الدمج and send the output; (c) switch the map card to Google Maps/Waze/HudHud → "تشغيل داخل البطاقة" and report if it floats inside the card or goes full screen; (d) ⌖ location button.
3. Next phase after that: sidebar/dock actions (car button, Android settings shortcut, AZ settings in the dock).

## Suggested commit messages
- "Phase 3: layout, backgrounds gallery, editor v2, prayer settings"
- "Phase 4: MediaSession + notification listener, permissions screen"
- "Phase 5: embedded map (OSM) with search/route and A-B style external window"


---
# SESSION 4 (version 0.4.0, versionCode 5)
Verification levels: **B** browser + simulated bridge, **C** Gradle build, **D** device. Only B was done this session; **C and D are NOT done** for any item below.

## Owner feedback from the device test (acted on)
- Freeform/embedding message confirmed: no external app inside the card on this firmware.
- Riyadh wallpaper must be optional, independent per theme.
- Media artwork larger, title on its own row.

## Phase 1 – Navigation (highest priority)
- [x] Research & comparison: `docs/NAVIGATION_RESEARCH.md` (Google Navigation SDK, Waze, HudHud, others, open-source). Google Navigation SDK = best, needs your key + billing (not implemented).
- [x] In-card navigation engine (B): real GPS from Java, OSRM routes with steps + alternatives (pick one), start/end, next-maneuver banner, distance, remaining distance/time/ETA, speed, heading-up rotation + auto-follow (drag pauses follow, ⌖ recenters), smooth marker, Arabic voice via Android TTS (English fallback if no Arabic voice), deviation → automatic reroute, GPS-loss warning, arrival.
- [x] Per-app diagnostics (Java `navApps`): installed, destination deep-link resolvable, last launch result; "test launch" button; never shown as supported unless a launch succeeded.
- [x] Full-screen hand-off with the destination for Google Maps (`google.navigation:`), Waze (`waze.com/ul?...navigate=yes`), HudHud (`geo:` + package).
- [x] Real freeform probe (`ProbeActivity`): measures the window granted for requested bounds; "run inside card" button only appears if the probe says bounds are honored.
- [ ] **Device test needed**: GPS fixes on the TBox, TTS Arabic availability, freeform probe result, hand-off to each app.
- [ ] Return-to-AZ overlay button (needs overlay permission): not built. Return = Home button (see Phase 2).
- BLOCKED on owner: Google Navigation SDK (key + billing).

## Phase 2 – Default launcher
- [x] Manifest already has MAIN+HOME+DEFAULT+LAUNCHER, `singleTask`, `resizeableActivity` (source review).
- [x] Settings › Permissions: status "AZ Drive is default" + button using RoleManager (Android 10+) or `ACTION_HOME_SETTINGS` fallback (source only, B).
- [ ] D: confirm the role dialog appears on the TBox firmware, Home button returns to AZ Drive, boot behaviour. Android requires user confirmation; nothing is forced.

## Phase 4 – Wallpapers (done, B)
- Independent selection for Day, Night, Auto-day, Auto-night (keys `day`,`night`,`autoDay`,`autoNight`); default = dashboard background (no image); Riyadh/mountain/desert/sky/city remain in the gallery; custom upload/delete per theme; preview/apply/cancel use the active theme; existing saved choices preserved. Tested: changing day does not change night/auto; persists after reload.

## Phase 5 – Media (done, B)
- Artwork +22% (6.4rem → 7.8rem); row 1 = artwork + artist/album (smaller) + source; row 2 = title up to 2 lines; if it still does not fit: single line with ellipsis and a horizontal move once every 25 s (stationary between, resets on track change, skipped when hidden). Tested with a fake clock; no overflow at 1536×864.
- Still needs device test with Spotify/YouTube/Brave.

## Phase 3 – Settings reorganization (NOT started – mapping prepared)
| Existing tab/control | New home |
|---|---|
| Colors (mode, accent, global colors, opacity, glow) | A. Appearance & Themes |
| Backgrounds | A. Appearance & Themes |
| Fonts, icon size/stroke/shape (Icons, General) | A. Appearance & Themes |
| Per-card appearance (card selector, size, border, bg, text) | B. Dashboard & Widgets |
| Layout presets, gap, size, lock, hide, swap | B. Dashboard & Widgets |
| Clock section (currently under Layout) | B. Dashboard & Widgets › Clock |
| Prayer settings (General), weather | B. Dashboard & Widgets › Prayer / Weather |
| Media source tab | C. Media |
| Maps tab (providers, diagnostics, probe, voice) | D. Navigation & Maps |
| Permissions, default launcher, About, profiles, import/export | E. System & Application |
Plan: keep all storage keys unchanged (no migration needed), only move controls between panes.

## Pending (unchanged from Session 3)
Sidebar car button, Android Settings shortcut, AZ settings in dock position, weather location editor, drag-and-drop, return-to-AZ overlay.

## Files changed this session
app/src/main/assets/index.html, app/src/main/java/com/azdrive/launcher/MainActivity.java, ProbeActivity.java (new), app/src/main/AndroidManifest.xml (ProbeActivity), app/build.gradle (0.4.0/5), docs/NAVIGATION_RESEARCH.md (new), PROJECT_PROGRESS.md.

## Build status
Not built (no Android SDK in the authoring environment). Java checked by brace/paren balance only. Last device-confirmed build: Build #26 (older code).

## Exact next step
1. Commit + run Actions build; send compile errors if any.
2. On the TBox: Editor › الخرائط → run "اختبار النوافذ الحرة", "اختبار التشغيل" for each app, check the voice line; set a destination and drive/walk with GPS to test guidance and reroute; Editor › الأذونات → set AZ Drive as default home.
3. Decide on Google Navigation SDK (key + billing) or keep the open-source engine; then Phase 3 (settings reorganization).

## Suggested commits
- "Phase 1: in-card turn-by-turn navigation engine, TTS, nav app diagnostics, freeform probe"
- "Phase 2: default launcher (HOME role) flow"
- "Phase 4/5: independent wallpapers per theme; media layout and periodic title marquee"
