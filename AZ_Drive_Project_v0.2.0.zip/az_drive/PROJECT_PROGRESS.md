# AZ Drive – PROJECT_PROGRESS.md
Branch to use: `feature/phase-2-webview-dashboard` (never `main`, never merge PR #1).
Version in this drop: 0.3.1 (versionCode 4). Last session: Session 3 – Phase "Map window (A-B style)" + regression fixes.

## Verification levels (read this first)
- **B** = verified in a desktop browser with a *simulated* native bridge (Playwright). Not Android.
- **C** = compiled by Gradle / GitHub Actions. **NOT DONE for this drop** (no Android SDK in the authoring environment). Java was only checked by brace balance.
- **D** = tested on the Carlinkit TBox Ultra. **NOT DONE for anything in this drop.** (Earlier builds up to the editor v2 were run on the device by the owner: dashboard, weather, prayer times, day background upload.)

## Completed (B only unless stated)
- Layout: top header (location/temperature) removed; cards start at the same top as the rail; larger map card; dock kept at the bottom; gap row above dock for the skyline.
- Clock: 24h digital + analog, Gregorian + Hijri, centered date, faces/styles/size editor. Fix this session: digital+analog fit on one row (container units).
- Prayer times: AlAdhan, 5 prayers + sunrise, next-prayer highlight, live countdown, daily refresh, settings (city, country, method, Asr school, minute adjustment). 
- Weather: Open-Meteo (temp, condition, hi/lo, feels-like, humidity, wind + direction, UV, rain %), AQI (Open-Meteo air quality), last-update time, cached when offline.
- Day/Night/Auto using Riyadh sunrise/sunset; per-theme accent; per-theme backgrounds.
- Backgrounds: supplied Riyadh day/night + 2 mountain photos, 3 generated "design" wallpapers, gallery with preview/apply/cancel, custom upload (day/night separately), position/zoom/brightness/blur/opacity, horizon auto-align above the dock.
- Editor (9 tabs): colors, backgrounds, layout (presets, per-card size via grid tracks, swap position, lock, hide), icons (size, stroke, shape, dock add/remove/reorder), maps, media source, permissions, general (fonts, 12/24h, date visibility, prayer settings, profiles, import/export), about. Undo/redo, reset card/all, persistence (localStorage + native SharedPreferences mirror).
- Dock: real installed-app icons through PackageManager (Java `list()`), add/remove/reorder.
- Media card: renders real MediaSession data pushed by Java (title, artist, album, art, source, progress, elapsed/remaining, play/pause, next/previous, ±15s seek, tap-to-seek, source selection). Fix this session: a duplicate function name had silently prevented the media card from updating.
- Map card: embedded interactive OpenStreetMap map (drag, pinch/wheel zoom, search via Nominatim, route via OSRM, distance/ETA, location marker when Java sends it). Night mode = dark-filtered tiles.
- Map card A-B style window (this session): provider switch ⇄ (AZ map / Google Maps / Waze / HudHud) *inside the map card only*; external providers launch through `ActivityOptions.setLaunchBounds` with the card rectangle; fallback = full-screen launch. Diagnostics in Editor › Maps (installed apps, freeform capability).

## Partially completed
- MediaSession: Java side written (MediaSessionManager + NotificationListenerService `MediaListener`), **uncompiled and untested on device**. Shuffle/repeat removed (not exposed by the framework controller API). Brave metadata depends on what Brave publishes.
- Location on the map: Java LocationManager bridge written, uncompiled/untested; the TBox may have no GPS.
- Permissions screen: status + links (location request, notification listener settings, app info for restricted-settings on Android 13+). Untested on device.
- Layout editing: sizes are grid-track based (shared by cards in the same row/column); swap instead of free drag-and-drop.

## Blocked / cannot be promised
- **Embedding another app's Activity inside the WebView card is not possible on stock Android.** Activity Embedding (Jetpack WindowManager) only works for activities the host owns or that opt in with `allowUntrustedActivityEmbedding`; VirtualDisplay/ActivityView need system privileges.
- The A-B-style card window depends on the firmware supporting freeform windows. If it does not, the app opens full screen. Existing task windows are not re-positioned by a second launch. Only the device test can tell.
- Google Maps JS/SDK and HudHud SDK were NOT integrated (keys/billing/licensing need an owner decision).
- No Riyadh photo can be generated; supplied photos are used.

## Pending (not started)
- Sidebar: car button action; Android System Settings shortcut in the sidebar; AZ settings shortcut placed in the dock position agreed with the owner (currently the rail "الإعدادات" opens the AZ editor).
- Weather location editor (only prayer city is configurable).
- True drag-and-drop layout editing; changing glyph sets for dashboard icons.
- Turn-by-turn navigation (use the external provider).

## Known bugs / risks
- Gradle build of this drop not yet run: possible Java compile errors (API usage written without a compiler). Send the Actions log for fixing.
- OSM tile/Nominatim/OSRM public servers have usage policies; fine for personal use, not for distribution.
- The tile map flashes blank for a moment when changing zoom level.

## Files modified in this drop (relative to v0.2.0)
app/src/main/assets/index.html (rewritten UI), app/src/main/assets/bg/* (new), app/src/main/java/com/azdrive/launcher/MainActivity.java (rewritten), MediaListener.java (new), app/src/main/AndroidManifest.xml (listener service, location permissions, singleTask, resizeableActivity), app/build.gradle (0.3.1 / 4), PROJECT_PROGRESS.md.

## Latest build status
Not built (no SDK here). Last owner-confirmed build on the device: Build #26 (earlier code).

## Exact next step
1. Commit this drop on `feature/phase-2-webview-dashboard`; run the Actions build; paste any compile errors back.
2. Device checklist: (a) notification access → play Spotify/YouTube/Brave and watch the media card; (b) Editor › Maps › فحص إمكانية الدمج and send the output; (c) switch the map card to Google Maps/Waze/HudHud → "تشغيل داخل البطاقة" and report if it floats inside the card or goes full screen; (d) ⌖ location button.
3. Next phase after that: sidebar/dock actions (car button, Android settings shortcut, AZ settings in the dock).

## Independent source audit (2026-11-27)
- Reviewed the delivered ZIP source; this is a source review, not a Gradle build or TBox test.
- JavaScript inline script passes `node --check` in the review environment.
- Corrected the map diagnostic so a developer setting (`enable_freeform_support`) is not presented as proof that the firmware advertises freeform-window support. The diagnostic now distinguishes the system feature from the developer setting and explicitly says neither guarantees in-card behavior.
- Corrected README permission guidance: MediaSession discovery requires the user to enable AZ Drive in Android Notification Access; map location is optional. The previous README statement incorrectly said notification permission was not required.
- Gradle/Android Java compilation remains unverified: no Gradle executable, Android SDK, or `android.jar` was available in the review environment.
- TBox runtime behavior remains unverified. `ActivityOptions.setLaunchBounds()` requests launch bounds; it does not prove that the external app will remain inside the map card.

## Suggested commit messages
- "Phase 3: layout, backgrounds gallery, editor v2, prayer settings"
- "Phase 4: MediaSession + notification listener, permissions screen"
- "Phase 5: embedded map (OSM) with search/route and A-B style external window"
