package com.azdrive.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 13, 21);
    private static final int PANEL = Color.rgb(17, 26, 39);
    private static final int PANEL2 = Color.rgb(22, 34, 49);
    private static final int CYAN = Color.rgb(57, 199, 244);
    private static final int WHITE = Color.rgb(237, 244, 250);
    private static final int MUTED = Color.rgb(139, 157, 176);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView clock, date, temperature, weather, nextPrayer, prayerCountdown, status;
    private String prayerName = "جاري تحميل المواقيت";
    private long nextPrayerMillis = -1;

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            Calendar now = Calendar.getInstance();
            clock.setText(new SimpleDateFormat("hh:mm", Locale.getDefault()).format(now.getTime()));
            date.setText(new SimpleDateFormat("EEEE، d MMMM yyyy", new Locale("ar")).format(now.getTime()));
            if (nextPrayerMillis > 0) {
                long diff = Math.max(0, nextPrayerMillis - System.currentTimeMillis());
                long h = diff / 3600000, m = (diff / 60000) % 60, s = (diff / 1000) % 60;
                prayerCountdown.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildDashboard();
        handler.post(clockTick);
        refreshLiveData();
    }

    private void buildDashboard() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setPadding(dp(12), dp(10), dp(12), dp(10)); root.setBackgroundColor(BG);

        LinearLayout rail = new LinearLayout(this); rail.setOrientation(LinearLayout.VERTICAL); rail.setGravity(Gravity.CENTER); rail.setPadding(0, dp(4), 0, dp(4));
        rail.setBackground(round(PANEL, 22));
        addRailButton(rail, "AZ", "الرئيسية", () -> buildDashboard());
        addRailButton(rail, "⌖", "الخرائط", () -> launchPackage("com.google.android.apps.maps"));
        addRailButton(rail, "▶", "الفيديو", () -> showApps());
        addRailButton(rail, "♫", "الموسيقى", () -> launchPackage("com.google.android.youtube.music"));
        addRailButton(rail, "▦", "التطبيقات", this::showApps);
        addRailButton(rail, "⚙", "الإعدادات", () -> startActivity(new Intent(Settings.ACTION_SETTINGS)));
        root.addView(rail, new LinearLayout.LayoutParams(dp(66), -1));

        LinearLayout gap = new LinearLayout(this); root.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));

        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(main, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout mapPanel = panel(); mapPanel.setGravity(Gravity.CENTER); mapPanel.setPadding(dp(22), dp(18), dp(22), dp(18));
        TextView mapIcon = text("⌖", 58, CYAN, true); mapIcon.setGravity(Gravity.CENTER);
        TextView mapTitle = text("الملاحة", 25, WHITE, true); mapTitle.setGravity(Gravity.CENTER);
        TextView mapSub = text("افتح خرائط Google أو تطبيق الملاحة المفضل", 13, MUTED, false); mapSub.setGravity(Gravity.CENTER);
        Button mapButton = actionButton("فتح Google Maps", true); mapButton.setOnClickListener(v -> launchPackage("com.google.android.apps.maps"));
        mapPanel.addView(mapIcon); mapPanel.addView(mapTitle); mapPanel.addView(mapSub); mapPanel.addView(space(18)); mapPanel.addView(mapButton);
        main.addView(mapPanel, new LinearLayout.LayoutParams(0, -1, 1.15f));
        main.addView(spaceHorizontal(10), new LinearLayout.LayoutParams(dp(10), 1));

        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        main.addView(right, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout weatherCard = panel(); weatherCard.setPadding(dp(16), dp(12), dp(16), dp(12)); weatherCard.setGravity(Gravity.CENTER_VERTICAL);
        TextView city = text("الرياض  •  الطقس", 13, MUTED, true);
        temperature = text("--°", 30, WHITE, true); weather = text("جاري تحديث الطقس", 12, MUTED, false);
        weatherCard.addView(city); weatherCard.addView(temperature); weatherCard.addView(weather);
        top.addView(weatherCard, new LinearLayout.LayoutParams(0, dp(112), 1));
        LinearLayout timeCard = panel(); timeCard.setPadding(dp(16), dp(10), dp(16), dp(10)); timeCard.setGravity(Gravity.CENTER);
        clock = text("--:--", 38, WHITE, true); date = text("", 12, MUTED, false);
        timeCard.addView(clock); timeCard.addView(date);
        LinearLayout.LayoutParams timeLp = new LinearLayout.LayoutParams(0, dp(112), 1); timeLp.setMargins(dp(8), 0, 0, 0); top.addView(timeCard, timeLp);
        right.addView(top);

        LinearLayout prayer = panel(); prayer.setPadding(dp(18), dp(12), dp(18), dp(12)); prayer.setOrientation(LinearLayout.HORIZONTAL); prayer.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout prayerLeft = new LinearLayout(this); prayerLeft.setOrientation(LinearLayout.VERTICAL);
        prayerLeft.addView(text("الصلاة القادمة", 12, MUTED, true));
        nextPrayer = text(prayerName, 22, WHITE, true); prayerLeft.addView(nextPrayer);
        prayer.addView(prayerLeft, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout prayerRight = new LinearLayout(this); prayerRight.setOrientation(LinearLayout.VERTICAL); prayerRight.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
        prayerCountdown = text("--:--:--", 27, CYAN, true); prayerRight.addView(prayerCountdown); prayerRight.addView(text("متبقي على الأذان", 11, MUTED, false));
        prayer.addView(prayerRight);
        LinearLayout.LayoutParams prayerLp = new LinearLayout.LayoutParams(-1, dp(102)); prayerLp.setMargins(0, dp(8), 0, 0); right.addView(prayer, prayerLp);

        LinearLayout media = panel(); media.setPadding(dp(16), dp(12), dp(16), dp(12)); media.setOrientation(LinearLayout.VERTICAL);
        TextView mediaTitle = text("الترفيه والتطبيقات", 15, WHITE, true); media.addView(mediaTitle);
        TextView mediaHint = text("افتح ثمانية أو YouTube أو Brave أو أي تطبيق مثبت", 11, MUTED, false); media.addView(mediaHint);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button brave = actionButton("Brave / YouTube", false); brave.setOnClickListener(v -> launchPackage("com.brave.browser"));
        Button youtube = actionButton("YouTube", false); youtube.setOnClickListener(v -> launchPackage("com.google.android.youtube"));
        Button apps = actionButton("كل التطبيقات", true); apps.setOnClickListener(v -> showApps());
        buttons.addView(brave, new LinearLayout.LayoutParams(0, dp(48), 1));
        buttons.addView(youtube, new LinearLayout.LayoutParams(0, dp(48), 1));
        buttons.addView(apps, new LinearLayout.LayoutParams(0, dp(48), 1));
        media.addView(space(8)); media.addView(buttons);
        LinearLayout.LayoutParams mediaLp = new LinearLayout.LayoutParams(-1, 0, 1); mediaLp.setMargins(0, dp(8), 0, 0); right.addView(media, mediaLp);

        status = text("AZ DRIVE  •  Android 15  •  Riyadh", 10, MUTED, false); status.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, dp(22)); statusLp.setMargins(0, dp(4), 0, 0); right.addView(status, statusLp);

        setContentView(root);
    }

    private void showApps() {
        java.util.List<android.content.pm.ResolveInfo> list = getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        java.util.Collections.sort(list, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(getPackageManager()).toString(), b.loadLabel(getPackageManager()).toString()));
        String[] names = new String[list.size()];
        for (int i=0;i<list.size();i++) names[i] = list.get(i).loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this).setTitle("التطبيقات المثبتة").setItems(names, (d, which) -> {
            try { Intent launch = getPackageManager().getLaunchIntentForPackage(list.get(which).activityInfo.packageName); if (launch != null) startActivity(launch); }
            catch (Exception e) { toast("تعذر فتح التطبيق"); }
        }).setNegativeButton("إغلاق", null).show();
    }

    private void launchPackage(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) startActivity(i); else showApps();
        } catch (ActivityNotFoundException e) { showApps(); }
    }

    private void refreshLiveData() {
        io.execute(() -> {
            try {
                URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=24.7136&longitude=46.6753&current=temperature_2m,weather_code&timezone=Asia%2FRiyadh");
                HttpURLConnection c = (HttpURLConnection)u.openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000);
                JSONObject root = new JSONObject(readResponse(c));
                JSONObject current = root.getJSONObject("current"); final String temp = Math.round(current.getDouble("temperature_2m")) + "°";
                final String desc = weatherDescription(current.optInt("weather_code"));
                runOnUiThread(() -> { temperature.setText(temp); weather.setText(desc); }); c.disconnect();
            } catch (Exception ignored) { runOnUiThread(() -> weather.setText("الطقس غير متاح حالياً")); }
            fetchPrayerTimes();
        });
        handler.postDelayed(this::refreshLiveData, 30 * 60 * 1000L);
    }

    private void fetchPrayerTimes() {
        try {
            String today = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
            URL u = new URL("https://api.aladhan.com/v1/timingsByCity/" + today + "?city=Riyadh&country=Saudi%20Arabia&method=4");
            HttpURLConnection c = (HttpURLConnection)u.openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000);
            JSONObject root = new JSONObject(readResponse(c));
            JSONObject timings = root.getJSONObject("data").getJSONObject("timings");
            String[] keys = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
            String[] names = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
            Calendar now = Calendar.getInstance(); long selected = -1; String selectedName = "";
            for (int i=0;i<keys.length;i++) {
                String hhmm = timings.getString(keys[i]).substring(0,5);
                String[] p = hhmm.split(":"); Calendar t = (Calendar)now.clone(); t.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0])); t.set(Calendar.MINUTE, Integer.parseInt(p[1])); t.set(Calendar.SECOND,0); t.set(Calendar.MILLISECOND,0);
                if (t.getTimeInMillis() > now.getTimeInMillis()) { selected=t.getTimeInMillis(); selectedName=names[i]; break; }
            }
            if (selected < 0) {
                String hhmm = timings.getString("Fajr").substring(0,5); String[] p=hhmm.split(":"); Calendar t=(Calendar)now.clone(); t.add(Calendar.DAY_OF_MONTH,1); t.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0])); t.set(Calendar.MINUTE,Integer.parseInt(p[1])); t.set(Calendar.SECOND,0); t.set(Calendar.MILLISECOND,0); selected=t.getTimeInMillis(); selectedName="الفجر";
            }
            final long millis=selected; final String name=selectedName;
            runOnUiThread(() -> { nextPrayerMillis=millis; prayerName=name; nextPrayer.setText(name); }); c.disconnect();
        } catch (Exception e) { runOnUiThread(() -> nextPrayer.setText("تعذر تحديث المواقيت")); }
    }

    private String readResponse(HttpURLConnection connection) throws Exception {
        java.io.InputStream in = connection.getInputStream();
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[4096]; int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        in.close(); return out.toString("UTF-8");
    }

    private String weatherDescription(int code) {
        if (code == 0) return "صحو"; if (code <= 3) return "غائم جزئياً"; if (code <= 48) return "ضباب"; if (code <= 67) return "أمطار"; if (code <= 77) return "ثلوج"; if (code <= 82) return "زخات مطر"; if (code >= 95) return "عواصف رعدية"; return "حالة الطقس";
    }

    private void addRailButton(LinearLayout rail, String symbol, String label, Runnable action) {
        TextView b = text(symbol, 23, CYAN, true); b.setGravity(Gravity.CENTER); b.setBackground(round(PANEL2, 16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(48), dp(48)); p.setMargins(0, dp(5), 0, dp(2)); rail.addView(b,p); b.setOnClickListener(v -> action.run());
        TextView t = text(label, 9, MUTED, false); t.setGravity(Gravity.CENTER); rail.addView(t, new LinearLayout.LayoutParams(dp(62), dp(16)));
    }
    private LinearLayout panel() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(round(PANEL, 20)); return l; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private Button actionButton(String label, boolean primary) { Button b = new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false); b.setTextColor(primary?BG:WHITE); b.setBackground(round(primary?CYAN:PANEL2,14)); return b; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), Color.rgb(34,55,75)); return d; }
    private View space(int h) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private View spaceHorizontal(int w) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1)); return v; }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void toast(String s) { android.widget.Toast.makeText(this,s,android.widget.Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); io.shutdownNow(); }
}
