# AZ Drive — Android launcher prototype

Target device: Carlinkit TBox Ultra, firmware reported by owner: `X21-SC162-4 A15` (Android 15).

## Included in this prototype
- Android HOME/DEFAULT launcher intent filter.
- Landscape-first dark dashboard UI with cyan accents.
- Riyadh weather from Open-Meteo (no API key).
- Riyadh prayer countdown from AlAdhan API using method 4 (Umm al-Qura).
- Shortcuts to Google Maps, Brave, YouTube Music, YouTube and an installed-app picker.

## Important limitations
- This is a first prototype, not a verified production APK.
- It launches other apps; it does not embed third-party app windows inside its own UI. The device's existing Android split-screen feature must be used for Maps + video side-by-side. Freeform/multi-window behavior depends on the TBox firmware.
- Thmanyah is available through the installed-app picker if it is installed. Its package name is intentionally not assumed.
- Prayer and weather data require internet. Prayer calculation is requested from AlAdhan using Umm al-Qura method 4; verify the timings against the local authority before relying on them.
- Default launcher selection and automatic startup must be tested on the actual TBox. Android may show a Home-app chooser or require the user to select AZ Drive as default.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Requirements: Android SDK Platform 35, JDK 17 or newer, Android Gradle Plugin 8.7.3.

## Install
Install the generated APK on the TBox. Press Home and choose AZ Drive, then choose Always if Android offers that option. Keep the original launcher installed so it remains available as a fallback.

## Safety
Do not disable Play Protect or grant Accessibility/notification permissions to this prototype. It does not require those permissions.
